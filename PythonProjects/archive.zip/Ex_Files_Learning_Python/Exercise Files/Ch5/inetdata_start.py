# 
# Example file for retrieving data from the internet
#


if __name__ == "__main__":
  main()
