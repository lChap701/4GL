#
# Example file for working with loops
#

def main():
  x = 0

  # define a while loop


  # define a for loop


  # use a for loop over a collection
    
 
  # use the break and continue statements


  #using the enumerate() function to get index 


if __name__ == "__main__":
  main()
